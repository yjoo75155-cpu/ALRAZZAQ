# الرزاق — Android APK

Android WebView wrapper for the الرزاق PWA.

## GitHub Actions
The workflow is at `.github/workflows/rizaq-apk.yml` and builds:
`app/build/outputs/apk/debug/app-debug.apk`

After the workflow succeeds, download the artifact named `الرزاق-debug-apk`.

## Project root
`settings.gradle`, `build.gradle`, and `app/` are intentionally at repository root. Do not put the workflow inside `app/`.
