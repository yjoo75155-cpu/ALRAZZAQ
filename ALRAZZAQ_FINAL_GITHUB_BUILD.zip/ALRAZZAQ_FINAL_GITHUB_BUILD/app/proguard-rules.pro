# No custom rules required for ALRAZZAQ.
